#!/usr/bin/env python3
"""
export_station_json.py
-----------------------
Phase 5 of the VR Hydrology Digital Twin onboarding guide: converts per-station
CSV exports (discharge history, climate, soil, forecast + uncertainty bounds)
into a single JSON bundle per station, ready to ship in Unity's StreamingAssets
folder -- plus a flattened CSV of the same data for spreadsheet / non-Unity use.

Each station's JSON carries an explicit "period" (the start and end date of
its discharge readings) and a "forecastPeriod" (the start and end date of its
forecast), so a consumer never has to infer the interval by scanning the
readings array.

Usage:
    python export_station_json.py
    python export_station_json.py --stations-file stations.json \
        --sample-data sample_data --output output \
        --unity-streaming-assets ../unity-project/Assets/StreamingAssets/stations
"""
from __future__ import annotations

import argparse
import csv
import json
import shutil
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent


def load_station_list(stations_file: Path) -> list[dict]:
    with open(stations_file, "r", encoding="utf-8") as f:
        return json.load(f)["stations"]


def date_range(dates: list[str]) -> dict:
    ordered = sorted(dates)
    return {"start": ordered[0], "end": ordered[-1]} if ordered else {"start": None, "end": None}


def build_station_record(station: dict, data_dir: Path) -> dict:
    station_id = station["stationId"]

    discharge_csv = data_dir / "discharge" / f"{station_id}.csv"
    climate_csv = data_dir / "climate" / f"{station_id}.csv"
    soil_csv = data_dir / "soil" / f"{station_id}.csv"
    forecast_csv = data_dir / "forecast" / f"{station_id}.csv"

    for path in (discharge_csv, climate_csv, soil_csv, forecast_csv):
        if not path.exists():
            raise FileNotFoundError(
                f"Missing {path} for station '{station_id}'. "
                f"Every station listed in stations.json needs a CSV in each "
                f"of discharge/, climate/, soil/, and forecast/."
            )

    discharge_df = pd.read_csv(discharge_csv)
    climate_df = pd.read_csv(climate_csv)
    soil_df = pd.read_csv(soil_csv)
    forecast_df = pd.read_csv(forecast_csv)

    readings = [
        {"date": str(row.date), "dischargeCfs": float(row.discharge_cfs)}
        for row in discharge_df.itertuples(index=False)
    ]
    # Readings carry full timestamps in some live pulls (e.g. "2026-09-09T08:30:00-05:00");
    # sort/range on just the date portion so a same-day multi-reading pull still ranges correctly.
    period = date_range([r["date"][:10] for r in readings])

    climate_row = climate_df.iloc[0]
    climate = {
        "avgTempC": float(climate_row.avg_temp_c),
        "avgPrecipMm": float(climate_row.avg_precip_mm),
        # as_of_date is optional -- present for a live single-point climate pull,
        # absent for a true multi-day average (older CSVs / synthetic data).
        "asOfDate": str(climate_row.as_of_date) if "as_of_date" in climate_df.columns else None,
    }

    soil_row = soil_df.iloc[0]
    soil = {
        "type": str(soil_row.soil_type),
        "infiltrationRateMmHr": float(soil_row.infiltration_rate_mm_hr),
    }

    forecast = [
        {
            "date": str(row.date),
            "dischargeCfs": float(row.discharge_cfs),
            "lowerBound": float(row.lower_bound),
            "upperBound": float(row.upper_bound),
        }
        for row in forecast_df.itertuples(index=False)
    ]
    forecast_period = date_range([f["date"][:10] for f in forecast])

    return {
        "stationId": station_id,
        "name": station["name"],
        "latitude": station["latitude"],
        "longitude": station["longitude"],
        "period": period,
        "readings": readings,
        "climate": climate,
        "soil": soil,
        "forecastPeriod": forecast_period,
        "forecast": forecast,
    }


def write_flattened_csv(record: dict, out_path: Path) -> None:
    """One row per reading/forecast point, plus repeated station/climate/soil
    columns -- a spreadsheet-friendly mirror of the JSON, for anyone who wants
    the packaged output without parsing nested JSON."""
    with open(out_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "station_id", "station_name", "latitude", "longitude",
            "row_type", "date", "discharge_cfs", "lower_bound", "upper_bound",
            "avg_temp_c", "avg_precip_mm", "climate_as_of_date",
            "soil_type", "infiltration_rate_mm_hr",
        ])
        common = [
            record["stationId"], record["name"], record["latitude"], record["longitude"],
        ]
        climate_cols = [
            record["climate"]["avgTempC"], record["climate"]["avgPrecipMm"], record["climate"]["asOfDate"],
        ]
        soil_cols = [record["soil"]["type"], record["soil"]["infiltrationRateMmHr"]]

        for r in record["readings"]:
            w.writerow(common + ["reading", r["date"], r["dischargeCfs"], "", ""] + climate_cols + soil_cols)
        for fpt in record["forecast"]:
            w.writerow(common + ["forecast", fpt["date"], fpt["dischargeCfs"], fpt["lowerBound"], fpt["upperBound"]] + climate_cols + soil_cols)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stations-file", type=Path, default=HERE / "stations.json")
    parser.add_argument("--sample-data", type=Path, default=HERE / "sample_data")
    parser.add_argument("--output", type=Path, default=HERE / "output")
    parser.add_argument(
        "--unity-streaming-assets",
        type=Path,
        default=HERE.parent / "unity-project" / "Assets" / "StreamingAssets" / "stations",
    )
    args = parser.parse_args()

    stations = load_station_list(args.stations_file)
    args.output.mkdir(parents=True, exist_ok=True)

    written = []
    for station in stations:
        record = build_station_record(station, args.sample_data)

        json_path = args.output / f"{station['stationId']}.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(record, f, indent=2)
        written.append(json_path)

        csv_path = args.output / f"{station['stationId']}.csv"
        write_flattened_csv(record, csv_path)
        written.append(csv_path)

        print(f"wrote {json_path.name} + {csv_path.name} "
              f"(period {record['period']['start']} to {record['period']['end']}, "
              f"{len(record['readings'])} readings, "
              f"forecast {record['forecastPeriod']['start']} to {record['forecastPeriod']['end']})")

    if args.unity_streaming_assets:
        args.unity_streaming_assets.mkdir(parents=True, exist_ok=True)
        for out_path in written:
            shutil.copy2(out_path, args.unity_streaming_assets / out_path.name)
        print(f"copied {len(written)} file(s) (JSON + CSV per station) to {args.unity_streaming_assets}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
