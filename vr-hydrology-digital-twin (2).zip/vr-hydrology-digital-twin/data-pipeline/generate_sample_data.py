#!/usr/bin/env python3
"""
generate_sample_data.py
------------------------
Creates synthetic placeholder CSVs for the three demo stations listed in
stations.json, in the shape export_station_json.py expects. Run this once to
populate sample_data/ (already committed to the repo), or re-run it to
regenerate fresh synthetic data. This script is NOT part of the real data
pipeline -- it exists only so the project has something to load before real
exports from the lab's research pipeline are wired up.
"""
from __future__ import annotations

import csv
import json
import math
import random
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
STATIONS_FILE = HERE / "stations.json"
SAMPLE_DATA = HERE / "sample_data"

HISTORY_DAYS = 30
FORECAST_DAYS = 7
START_DATE = date(2026, 8, 10)

SOIL_TYPES = ["clay loam", "sandy loam", "silty clay"]


def synth_discharge_series(base: float, days: int, start: date, seed: int) -> list[tuple[date, float]]:
    rng = random.Random(seed)
    series = []
    for i in range(days):
        d = start + timedelta(days=i)
        seasonal = 15 * math.sin(i / 6.0)
        noise = rng.uniform(-8, 8)
        value = max(5.0, base + seasonal + noise)
        series.append((d, round(value, 1)))
    return series


def main() -> None:
    with open(STATIONS_FILE, "r", encoding="utf-8") as f:
        stations = json.load(f)["stations"]

    for d in ("discharge", "climate", "soil", "forecast"):
        (SAMPLE_DATA / d).mkdir(parents=True, exist_ok=True)

    for idx, station in enumerate(stations):
        station_id = station["stationId"]
        seed = 1000 + idx
        rng = random.Random(seed)
        base_flow = rng.uniform(150, 500)

        # Discharge history
        history = synth_discharge_series(base_flow, HISTORY_DAYS, START_DATE, seed)
        with open(SAMPLE_DATA / "discharge" / f"{station_id}.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["date", "discharge_cfs"])
            for d, v in history:
                w.writerow([d.isoformat(), v])

        # Climate (single snapshot row)
        with open(SAMPLE_DATA / "climate" / f"{station_id}.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["avg_temp_c", "avg_precip_mm", "as_of_date"])
            w.writerow([round(rng.uniform(18, 32), 1), round(rng.uniform(1.5, 6.0), 1), (START_DATE + timedelta(days=HISTORY_DAYS - 1)).isoformat()])

        # Soil (single snapshot row)
        with open(SAMPLE_DATA / "soil" / f"{station_id}.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["soil_type", "infiltration_rate_mm_hr"])
            w.writerow([rng.choice(SOIL_TYPES), round(rng.uniform(3.0, 12.0), 1)])

        # Forecast + uncertainty bounds, continuing from the last history value
        forecast_start = START_DATE + timedelta(days=HISTORY_DAYS)
        last_value = history[-1][1]
        with open(SAMPLE_DATA / "forecast" / f"{station_id}.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["date", "discharge_cfs", "lower_bound", "upper_bound"])
            value = last_value
            for i in range(FORECAST_DAYS):
                d = forecast_start + timedelta(days=i)
                value = max(5.0, value + rng.uniform(-10, 10))
                spread = value * (0.08 + 0.01 * i)  # widening uncertainty further out
                w.writerow([
                    d.isoformat(),
                    round(value, 1),
                    round(max(0.0, value - spread), 1),
                    round(value + spread, 1),
                ])

        print(f"generated sample data for {station_id}")


if __name__ == "__main__":
    main()
