#!/usr/bin/env python3
"""
fetch_live_data.py
-------------------
Live counterpart to generate_sample_data.py: pulls real discharge history from
the USGS Water Services API and real climate history from the Open-Meteo API
for every station in stations.json, and writes CSVs in the exact layout
export_station_json.py expects (see docs/05-phase-data-pipeline.md).

Both APIs are public and require no API key:
  - USGS NWIS daily values service: https://waterservices.usgs.gov/nwis/dv
    Parameter 00060 = mean daily discharge, cubic feet per second.
    Docs: https://waterservices.usgs.gov/rest/DV-Service.html
  - Open-Meteo archive + forecast: https://open-meteo.com/
    No key required; fair-use rate limits apply for non-commercial use.
    Docs: https://open-meteo.com/en/docs

Soil data has no equivalent free, per-point live API (USDA SSURGO/POLARIS
require spatial raster queries), so this script leaves sample_data/soil/*.csv
untouched -- it's still the lab's static soil characterization per station.

NOTE ON NETWORK ACCESS: this script needs normal outbound internet access to
waterservices.usgs.gov and (archive-)api.open-meteo.com. Some locked-down
sandboxes (including the one this project was originally scaffolded in) block
arbitrary outbound HTTPS by default -- if requests here time out or get
refused, run this script from a normal machine (your laptop, a CI runner,
etc.) instead.

Usage:
    pip install -r requirements.txt
    python fetch_live_data.py
    python fetch_live_data.py --days 30 --forecast-days 7
    python fetch_live_data.py --start-date 2026-08-11 --end-date 2026-09-08 --forecast-days 7
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import date, timedelta
from pathlib import Path

import requests

HERE = Path(__file__).resolve().parent

USGS_DV_URL = "https://waterservices.usgs.gov/nwis/dv/"
OPEN_METEO_ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
OPEN_METEO_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

REQUEST_TIMEOUT = 20  # seconds


def load_stations(stations_file: Path) -> list[dict]:
    with open(stations_file, "r", encoding="utf-8") as f:
        return json.load(f)["stations"]


def fetch_usgs_discharge(site_number: str, start: date, end: date) -> list[tuple[str, float]]:
    """Mean daily discharge (cfs) for [start, end] (inclusive) from USGS NWIS."""
    params = {
        "sites": site_number,
        "parameterCd": "00060",
        "startDT": start.isoformat(),
        "endDT": end.isoformat(),
        "format": "json",
        "siteStatus": "all",
    }
    resp = requests.get(USGS_DV_URL, params=params, timeout=REQUEST_TIMEOUT)
    resp.raise_for_status()
    data = resp.json()

    series = data.get("value", {}).get("timeSeries", [])
    if not series:
        raise ValueError(
            f"USGS returned no daily-value discharge series for site {site_number} "
            f"-- it may not report parameter 00060, or may be temporarily offline."
        )

    values = series[0]["values"][0]["value"]
    out = []
    for v in values:
        # USGS dateTime looks like "2026-08-10T00:00:00.000-05:00"
        d = v["dateTime"][:10]
        out.append((d, float(v["value"])))
    return out


def fetch_open_meteo_climate(lat: float, lon: float, start: date, end: date, forecast_days: int) -> list[tuple[str, float, float]]:
    """(date, avg_temp_c, precip_mm) for [start, end] (inclusive), stitching the
    archive endpoint (finalized past data) with the forecast endpoint's
    `past_days` window (last few days, not yet in the archive)."""
    results: dict[str, tuple[float, float]] = {}

    # Historical (archive) -- typically has a few days' lag before data lands.
    try:
        resp = requests.get(
            OPEN_METEO_ARCHIVE_URL,
            params={
                "latitude": lat, "longitude": lon,
                "start_date": start.isoformat(), "end_date": end.isoformat(),
                "daily": "temperature_2m_mean,precipitation_sum",
                "timezone": "auto",
            },
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        daily = resp.json().get("daily", {})
        for d, t, p in zip(daily.get("time", []), daily.get("temperature_2m_mean", []), daily.get("precipitation_sum", [])):
            if t is not None:
                results[d] = (t, p or 0.0)
    except requests.RequestException:
        pass  # fall through to forecast endpoint's past_days window below

    # Forecast endpoint also serves the most recent ~92 days via past_days,
    # which fills the gap the archive endpoint hasn't ingested yet.
    days_back = max(1, (date.today() - start).days)
    resp = requests.get(
        OPEN_METEO_FORECAST_URL,
        params={
            "latitude": lat, "longitude": lon,
            "daily": "temperature_2m_mean,precipitation_sum",
            "past_days": min(days_back, 92),
            "forecast_days": forecast_days,
            "timezone": "auto",
        },
        timeout=REQUEST_TIMEOUT,
    )
    resp.raise_for_status()
    daily = resp.json().get("daily", {})
    for d, t, p in zip(daily.get("time", []), daily.get("temperature_2m_mean", []), daily.get("precipitation_sum", [])):
        if t is not None and start.isoformat() <= d <= end.isoformat():
            results[d] = (t, p or 0.0)

    return [(d, *results[d]) for d in sorted(results)]


def naive_forecast(history: list[tuple[str, float]], forecast_days: int) -> list[tuple[str, float, float, float]]:
    """Placeholder forecast: persistence from the last observed discharge value
    with linearly widening uncertainty bounds. This is NOT the lab's ML model
    -- see docs/07-phase-ml-model.md. It exists so the Unity app has something
    non-empty to render in forecast panels until Phase 7 wires in the real
    model's output."""
    if not history:
        return []
    last_date = date.fromisoformat(history[-1][0])
    last_value = history[-1][1]
    out = []
    for i in range(1, forecast_days + 1):
        d = last_date + timedelta(days=i)
        spread = last_value * (0.06 + 0.015 * i)
        out.append((d.isoformat(), round(last_value, 1), round(max(0.0, last_value - spread), 1), round(last_value + spread, 1)))
    return out


def write_csv(path: Path, header: list[str], rows: list[tuple]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--stations-file", type=Path, default=HERE / "stations.json")
    parser.add_argument("--out", type=Path, default=HERE / "sample_data", help="Where to write discharge/climate/forecast CSVs (default: sample_data/, overwriting the synthetic placeholders)")
    parser.add_argument("--days", type=int, default=30, help="Days of trailing history to pull, ending yesterday (default 30). Ignored if --start-date/--end-date are given.")
    parser.add_argument("--start-date", type=str, default=None, help="Explicit interval start (YYYY-MM-DD). Overrides --days.")
    parser.add_argument("--end-date", type=str, default=None, help="Explicit interval end (YYYY-MM-DD), inclusive. Defaults to yesterday if --start-date is given without this.")
    parser.add_argument("--forecast-days", type=int, default=7, help="Days of placeholder forecast to generate (default 7)")
    args = parser.parse_args()

    if args.start_date:
        start = date.fromisoformat(args.start_date)
        end = date.fromisoformat(args.end_date) if args.end_date else date.today() - timedelta(days=1)
    else:
        end = date.today() - timedelta(days=1)
        start = end - timedelta(days=args.days - 1)
    if start > end:
        print(f"error: --start-date ({start}) is after --end-date ({end})")
        return 2

    stations = load_stations(args.stations_file)
    any_failed = False
    print(f"Interval: {start.isoformat()} to {end.isoformat()} ({(end - start).days + 1} days), "
          f"plus {args.forecast_days}-day forecast")

    for station in stations:
        site_number = station["stationId"].replace("USGS-", "")
        print(f"\n{station['stationId']} ({station['name']})")

        try:
            discharge = fetch_usgs_discharge(site_number, start, end)
            write_csv(args.out / "discharge" / f"{station['stationId']}.csv", ["date", "discharge_cfs"], discharge)
            print(f"  discharge: {len(discharge)} days from USGS NWIS "
                  f"(latest: {discharge[-1][0]} = {discharge[-1][1]} cfs)")
        except (requests.RequestException, ValueError) as e:
            any_failed = True
            print(f"  discharge: FAILED -- {e}")
            continue

        try:
            climate = fetch_open_meteo_climate(station["latitude"], station["longitude"], start, end, args.forecast_days)
            if climate:
                avg_temp = sum(c[1] for c in climate) / len(climate)
                avg_precip = sum(c[2] for c in climate) / len(climate)
                write_csv(args.out / "climate" / f"{station['stationId']}.csv",
                          ["avg_temp_c", "avg_precip_mm", "as_of_date"],
                          [(round(avg_temp, 1), round(avg_precip, 1), end.isoformat())])
                print(f"  climate: {len(climate)} days from Open-Meteo "
                      f"(avg {avg_temp:.1f}C, {avg_precip:.1f}mm/day, {start} to {end})")
            else:
                print("  climate: no data returned")
        except requests.RequestException as e:
            any_failed = True
            print(f"  climate: FAILED -- {e}")

        forecast = naive_forecast(discharge, args.forecast_days)
        write_csv(args.out / "forecast" / f"{station['stationId']}.csv",
                  ["date", "discharge_cfs", "lower_bound", "upper_bound"], forecast)
        print(f"  forecast: {len(forecast)} days (naive placeholder -- see docs/07-phase-ml-model.md)")

    print("\nNext: python export_station_json.py   (packages these CSVs into StreamingAssets JSON)")
    return 1 if any_failed else 0


if __name__ == "__main__":
    sys.exit(main())
