# Data Pipeline — Live Data to Station JSON

Implements Phase 5 of the onboarding guide: getting discharge, climate, soil,
and forecast data into the per-station JSON bundle the Unity application
loads from `StreamingAssets`. Two ways to populate it:

| Script | Source | Use it for |
|---|---|---|
| `fetch_live_data.py` | **Real APIs** — USGS Water Services (discharge) + Open-Meteo (climate) | Real station data, refreshed on demand |
| `generate_sample_data.py` | Synthetic, seeded random data | Offline iteration with no network dependency |

Both write into the same `sample_data/` folder layout, so `export_station_json.py`
doesn't care which one produced its input.

## Live data — `fetch_live_data.py`

Pulls, per station in `stations.json`:

- **Discharge** — mean daily values from the [USGS NWIS daily-values
  service](https://waterservices.usgs.gov/rest/DV-Service.html), parameter
  `00060` (cubic feet per second). No API key required.
- **Climate** — daily mean temperature and precipitation from
  [Open-Meteo](https://open-meteo.com/en/docs) (archive endpoint for
  finalized past days, forecast endpoint's `past_days` window for the most
  recent days the archive hasn't ingested yet). No API key required.
- **Forecast** — a **naive placeholder**: persistence from the latest
  discharge reading with linearly widening uncertainty bounds. This is *not*
  the lab's ML model — it exists only so the Unity app has a non-empty
  forecast panel to render. Swapping this for the real model's output is
  Phase 7 (see `docs/07-phase-ml-model.md`).
- **Soil** is left untouched — there's no equivalent free per-point live API
  (USDA SSURGO/POLARIS need spatial raster queries), so it stays the lab's
  static soil characterization per station.

```bash
pip install -r requirements.txt
python fetch_live_data.py                                                    # last 30 days, 7-day placeholder forecast
python fetch_live_data.py --days 14 --forecast-days 5                        # shorter windows
python fetch_live_data.py --start-date 2026-08-11 --end-date 2026-09-08      # explicit interval
```

**Network note:** this needs normal outbound HTTPS access to
`waterservices.usgs.gov` and `(archive-)api.open-meteo.com`. Locked-down
sandboxes (including the one this project was originally scaffolded in, which
blocks arbitrary outbound HTTPS by default) will refuse the connection —
run it from a normal machine, a CI runner, or anywhere with ordinary internet
access instead. `export_station_json.py` itself has no such requirement; it
only reads local CSVs.

The `sample_data/` CSVs currently committed to this repo are **real data**,
not synthetic: a full 29-day daily discharge history (2026-08-11 to
2026-09-08) from USGS for all three stations, plus a live temperature/
precipitation snapshot from the National Weather Service dated 2026-09-09
(`as_of_date` column — a single point-in-time reading, not a period average,
since a multi-day climate average wasn't reachable when this was captured).
Run `fetch_live_data.py` yourself to refresh either with a rolling window
(`--days`) or an explicit `--start-date`/`--end-date` interval.

## Synthetic data — `generate_sample_data.py`

```bash
python generate_sample_data.py
```

Regenerates `sample_data/` with seeded random discharge/climate/soil/forecast
data for whatever stations are listed in `stations.json` — useful for
iterating on the Unity scene without depending on either live API or real
lab exports.

## Input format (either source writes this)

Each station needs four CSVs, one per folder, named `<station_id>.csv`:

- `sample_data/discharge/<station_id>.csv` — columns: `date, discharge_cfs`
- `sample_data/climate/<station_id>.csv` — columns: `avg_temp_c,
  avg_precip_mm, as_of_date` (single row; `as_of_date` is optional — present
  for a live single-point pull, omit it for a true multi-day average)
- `sample_data/soil/<station_id>.csv` — columns: `soil_type,
  infiltration_rate_mm_hr` (single row)
- `sample_data/forecast/<station_id>.csv` — columns: `date, discharge_cfs,
  lower_bound, upper_bound`

Station metadata (display name, latitude, longitude) is defined in
`stations.json` in this folder. It currently lists three real USGS gauges on
the Trinity River (Dallas, Rosser, and Trinidad, TX) verified against the
USGS site service — edit it to point at your own watershed's stations.

## Packaging into Unity — `export_station_json.py`

```bash
python export_station_json.py
```

Output, per station:

- `output/<station_id>.json` — the packaged record, with explicit `period`
  (start/end of `readings`) and `forecastPeriod` (start/end of `forecast`)
  date-interval fields, so nothing has to be inferred by scanning the arrays.
- `output/<station_id>.csv` — a flattened mirror of the same record, one row
  per reading and one row per forecast point (`row_type` column
  distinguishes them), for spreadsheets/notebooks/anything that doesn't want
  to parse nested JSON.
- Both files are also copied to
  `../unity-project/Assets/StreamingAssets/stations/` — Unity loads the JSON
  at runtime; the CSV rides along as a human-readable mirror.

Pass `--stations-file` / `--sample-data` / `--output` / `--unity-streaming-assets`
to point the script at different locations (`python export_station_json.py --help`).
