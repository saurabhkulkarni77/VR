# Phase 7 · The Model — Integrating the ML forecasting model

## Three options

| | Approach | Notes |
|---|---|---|
| **Start here** | **A · Precomputed results** | Run the model on your workstation, export forecasts + uncertainty bounds as JSON, load them in Unity. No ML runtime on-device. |
| Upgrade path | **B · On-device inference** | Export to ONNX, run it with Unity Sentis (Inference Engine) directly on the Quest 3S GPU/CPU. Enables live "what-if" scenarios. |
| Alternative | **C · Server API** | Host the model behind a REST endpoint; call it from Unity over WiFi when the headset is connected. |

**Recommendation:** ship version 1 with option A (precomputed). Move to B or
C only once the core VR experience is stable. This repo's data pipeline
(`data-pipeline/export_station_json.py`) already implements option A — the
`forecast` array in each station's JSON is exactly the precomputed-results
payload Unity reads.

## Implementation steps for Option B (on-device inference, later)

1. **Export the trained model to ONNX** — from PyTorch or TensorFlow using
   their standard ONNX export utilities.
2. **Drop the `.onnx` file into Unity Assets** — Sentis (Unity's Inference
   Engine) auto-imports and optimizes it into a runnable asset.
3. **Write the inference script** — load the model, set the input tensor
   (the historical window), call `Schedule()`, and read back the output
   tensor (forecast plus bounds).
4. **Quantize & optimize** — convert to a quantized `.sentis` asset and add a
   warm-up pass so the first inference doesn't stutter in-headset.

## Resources

- Sentis / Inference Engine overview — docs.unity3d.com/Packages/com.unity.ai.inference
- Understand the Sentis workflow — docs.unity3d.com (Sentis manual)
- Unity Inference Engine on Meta Quest — developers.meta.com/horizon (unity-pca-sentis)
