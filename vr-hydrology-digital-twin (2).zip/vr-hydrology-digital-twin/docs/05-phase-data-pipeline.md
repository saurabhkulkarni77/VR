# Phase 5 · Data — Getting your dataset into Unity

## Design decision

- **Static snapshot (recommended to start)** — pre-export historical
  discharge, climate, and soil data as JSON/CSV bundled with the app;
  reliable for demos with no network dependency. **This is now live-sourced,
  not synthetic** — see below.
- **Live API refresh (add later)** — USGS Water Services exposes real-time
  (`/nwis/iv`) and daily (`/nwis/dv`) endpoints as JSON; call these from
  Unity to refresh readings when on WiFi.
- **Unity-side data layer** — `UnityWebRequest` or a bundled file → JSON
  parser → typed C# classes, ideally wrapped in a `ScriptableObject` so the
  rest of the scene reads from one clean data source.

## Live data pipeline (built in this repo)

`data-pipeline/fetch_live_data.py` pulls real data for every station in
`stations.json`:

- **Discharge** — USGS NWIS daily-values service (`/nwis/dv`), parameter
  `00060` (cfs). Real, public, no API key.
- **Climate** — Open-Meteo archive + forecast APIs (temperature, precipitation)
  by station lat/lon. Real, public, no API key.
- **Forecast** — a clearly-labeled **naive placeholder** (persistence +
  widening bounds), since the actual streamflow forecast has to come from the
  lab's own model (Phase 7), not a public API.
- **Soil** stays static — there's no free per-point live soil API equivalent
  to USGS/Open-Meteo (SSURGO/POLARIS need spatial raster queries).

The CSVs currently committed under `data-pipeline/sample_data/` are a **real
29-day discharge history (2026-08-11 to 2026-09-08) pulled from USGS, plus a
live climate snapshot from NWS on 2026-09-09**, for three Trinity River
gauges near Dallas, TX — not synthetic placeholders. Run
`python fetch_live_data.py` yourself (from a machine with normal outbound
internet access — see the caveat below) to refresh them, or pass an explicit
window with `--start-date`/`--end-date`.

**Sandbox network caveat:** `fetch_live_data.py` needs ordinary outbound
HTTPS to `waterservices.usgs.gov` and `api.open-meteo.com`. This project was
originally scaffolded inside a locked-down sandbox that blocks arbitrary
outbound HTTPS by default, so the live snapshot in this repo was captured by
querying those same public endpoints through an available fetch tool rather
than running the script directly in that environment. The script itself is
standard `requests`-based Python and works normally anywhere with ordinary
internet access — your laptop, a GitHub Actions runner, etc.

## Implementation steps (as built in this repo)

1. **Get discharge + climate CSVs, per station** — either live
   (`fetch_live_data.py`, real USGS + Open-Meteo data) or synthetic
   (`generate_sample_data.py`, for offline iteration). See
   `data-pipeline/sample_data/` for the CSV shape (swap in real exports from
   your research pipeline using the same columns, if you'd rather pull from
   the lab's own systems than the public APIs).
2. **Package as JSON + CSV** — `data-pipeline/export_station_json.py`
   converts each station's CSVs into one JSON file (`period`, `readings`,
   `climate`, `soil`, `forecastPeriod`, `forecast`) *and* one flattened CSV
   (one row per reading/forecast point) for anyone who wants the packaged
   output without parsing nested JSON — spreadsheets, notebooks, other
   non-Unity tooling.
3. **Load as StreamingAssets** — the script also copies both the JSON and
   the CSV into `unity-project/Assets/StreamingAssets/stations/` so the JSON
   ships inside the app (Unity itself only reads the JSON at runtime; the
   CSV rides along as a human-readable mirror).
4. **Parse into C# classes** — `unity-project/Assets/Scripts/Data/StationData.cs`
   defines the typed station/reading/forecast objects (`JsonUtility`
   compatible); `StationDataLoader.cs` reads each file from StreamingAssets
   at runtime via `UnityWebRequest` (required on Android/Quest, where
   StreamingAssets isn't a plain filesystem path) and populates the
   `StationDatabase` ScriptableObject.
5. **(Optional) Add a live refresh call** — a `UnityWebRequest` coroutine
   hits the USGS API on a timer and overwrites the cached values, mirroring
   what `fetch_live_data.py` does on the Python side. Not implemented yet in
   the Unity scaffold — `StationDataLoader.cs` has a TODO marking where it
   would go.

## JSON schema

`period` and `forecastPeriod` are explicit start/end date intervals, computed
by sorting the `readings`/`forecast` arrays — a consumer never has to infer
the range by scanning the array itself.

```json
{
  "stationId": "USGS-08057000",
  "name": "Trinity Rv at Dallas, TX",
  "latitude": 32.7748517,
  "longitude": -96.8219464,
  "period": { "start": "2026-08-11", "end": "2026-09-08" },
  "readings": [
    { "date": "2026-08-11", "dischargeCfs": 437.0 },
    { "date": "2026-09-08", "dischargeCfs": 421.0 }
  ],
  "climate": { "avgTempC": 29.0, "avgPrecipMm": 0.0, "asOfDate": "2026-09-09" },
  "soil": { "type": "sandy loam", "infiltrationRateMmHr": 3.6 },
  "forecastPeriod": { "start": "2026-09-09", "end": "2026-09-15" },
  "forecast": [
    { "date": "2026-09-09", "dischargeCfs": 421.0, "lowerBound": 389.4, "upperBound": 452.6 }
  ]
}
```

These are real values from the live snapshot (29 daily readings, only the
first/last shown above for brevity), not an illustrative example — see
`data-pipeline/README.md` for the full picture, and `output/*.csv` for the
flattened CSV mirror of the same record.

## Resources

- USGS Water Data APIs — api.waterdata.usgs.gov
- USGS Water Services (daily values) — waterservices.usgs.gov/rest/DV-Service.html
- Open-Meteo API docs — open-meteo.com/en/docs
- Getting real-time river data from USGS — Medium, Proto Bioengineering walkthrough
