# Phase 2 · Setup — Development environment

## Checklist

1. **Install Unity Hub + Editor** — Unity 6000.0.66f2 or later, with Android
   Build Support, OpenJDK, and Android SDK & NDK modules.
2. **Create a Meta developer account** — sign up at developers.meta.com and
   create an organization for the lab.
3. **Enable Developer Mode on the Quest 3S** — turn it on from the Meta
   Horizon mobile app, then pair the headset over USB.
4. **Install the Meta XR Core SDK** — via the Unity Asset Store, then run
   `Meta XR Tools → Project Setup Tool → Fix All`.
5. **Install Meta Quest Developer Hub (MQDH)** — desktop app for device logs,
   screen casting, and file transfer during development.

## Resources

- Set up Unity for VR development — developers.meta.com/horizon/documentation/unity
- Hardware & software requirements — developers.meta.com (unity-development-requirements)
- Meta XR All-in-One SDK — Unity Asset Store

## Where this repo fits in

Once the Meta XR Core SDK and XR Interaction Toolkit are installed, open
`unity-project/` in the editor — `Packages/manifest.json` already lists the
UPM packages this project's scripts expect (XR Interaction Toolkit, XR
Management, Input System, URP, Newtonsoft Json).
