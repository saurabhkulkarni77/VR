# Phase 3 · First Build — Your first VR scene ("Hello World")

## Steps

1. **Create a new 3D (URP) project** — Universal Render Pipeline keeps
   performance high on standalone hardware.
2. **Install the XR Interaction Toolkit** — via Package Manager; gives you
   locomotion and object-interaction building blocks.
3. **Add an XR Origin (VR) to the scene** — represents the player's head and
   hands; configure the Meta XR / OpenXR provider in Project Settings.
4. **Add basic locomotion & grab interactions** — teleport or smooth
   movement, plus grabbing a test object, to confirm input is working.
5. **Build & Run to the headset** — over USB or wirelessly; confirm the scene
   runs at a stable frame rate before moving on.

## Resources

- Unity Hello World for Meta Quest — developers.meta.com/horizon (unity-tutorial-hello-vr)
- XR Interaction Toolkit manual — docs.unity3d.com/Packages/com.unity.xr.interaction.toolkit
- Complete XR Interaction Toolkit Course — YouTube, full beginner walkthrough

## Tip

Start simple: get a single cube rendering and stable in the headset before
importing any real terrain or data (see `pitfalls-and-tips.md`).
