# Resource Library

## Official docs — VR & Unity

- Meta Horizon OS Developers (Unity) — developers.meta.com/horizon/documentation/unity
- Unity: VR and MR development manual — docs.unity3d.com/Manual/VROverview.html
- XR Interaction Toolkit manual — docs.unity3d.com/Packages/com.unity.xr.interaction.toolkit
- Cesium for Unity — cesium.com/learn/unity

## Courses & tutorials

- Unity Learn: Digital Twins with Unity — learn.unity.com/tutorial/introduction-to-digital-twins-with-unity
- Unity Learn: UI best practices for VR — learn.unity.com (XR Interaction Toolkit UI)
- XR Bootcamp: Unity VR Tutorial for Beginners — xrbootcamp.com
- GameDev Academy: free XR Interaction Toolkit courses — gamedevacademy.org

## Data & ML tools

- USGS Water Data APIs — api.waterdata.usgs.gov
- USGS Water Services (real-time / daily) — waterservices.usgs.gov/nwis
- Unity Sentis / Inference Engine — docs.unity3d.com/Packages/com.unity.ai.inference
- Immersive Analytics Toolkit (IATK) — GitHub, VR-native data visualization

## Background research

- Blueprint conceptualization for a river basin's digital twin — Hydrology Research (IWA Publishing)
- Hydrological data visualization based on digital twin — Springer Nature Link
- Immersive digital twins & AI-driven decision support for water reserves — MDPI Sustainability
