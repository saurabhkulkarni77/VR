# Phase 10 · Ship It — Build & deploy to the headset

## Deployment steps

1. **Switch build platform to Android** — `File → Build Settings → Android`,
   matching the Meta XR SDK's required Player Settings (minimum API level,
   IL2CPP, ARM64).
2. **Build the APK** — confirm the Meta XR Project Setup Tool shows no
   unresolved warnings first.
3. **Sideload for testing** — install via Meta Quest Developer Hub, `adb
   install`, or iterate quickly with Quest Link / Air Link over USB or WiFi.
4. **Share beyond the lab** — use Meta's App Lab or an internal test channel
   once you're ready for outside collaborators to try it.

## Resources

- Unity build & deployment docs — developers.meta.com/horizon/documentation/unity
- Meta Quest Developer Hub guide — developers.meta.com (MQDH)
