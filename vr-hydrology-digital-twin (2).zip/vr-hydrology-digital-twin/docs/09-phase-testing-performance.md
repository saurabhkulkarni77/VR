# Phase 9 · Quality — Testing & performance optimization

## Keep it comfortable to wear

- **Target 90 fps on the Quest 3S** — dropping below this threshold is the
  single biggest cause of VR motion sickness.
- **Bake lighting where possible** — real-time shadows on mobile-class GPUs
  are expensive; bake what doesn't need to move.
- **Reduce draw calls** — batch static terrain geometry and atlas UI
  textures.
- **Add LOD to terrain** — lower detail at a distance so frame rate holds up
  across the whole basin.
- **Profile continuously** — use the Unity Profiler plus the OVR Metrics Tool
  / Meta Quest Developer Hub to watch frame time as you add features, not
  just at the end.

## Resources

- Start Building with Quest 3 / 3S — developers.meta.com/horizon/blog (performance tips)
- Meta Quest Developer Hub — developers.meta.com (device tools)
