# Phase 8 · Assembly — The full digital twin scene

## Bring the pieces together

- **Combine every phase's output** — terrain + river network (Phase 4), data
  layer (Phase 5), dashboards (Phase 6), and model output (Phase 7) all live
  in one scene.
- **Core interaction loop** — player walks or teleports along the watershed;
  pointing at a gauge station spawns its info panel with live readings,
  history, and forecast.
- **Layer toggles** — a simple menu lets the viewer switch soil, climate, or
  river overlays on and off without leaving VR.

## Suggested code structure (implemented in this repo)

- **One central ScriptableObject holds all station data** —
  `unity-project/Assets/Scripts/Data/StationDatabase.cs` — every other system
  reads from it, nothing duplicates it.
- **Terrain, UI, and model scripts stay decoupled** — swapping in a new model
  or a new dataset shouldn't require touching the terrain code. That's why
  `StationMarker`, `StationPanelController`, and `RiverNetworkRenderer` each
  only depend on `StationDatabase`, never on each other directly.
- **Keep a debug scene with a tiny fake dataset** — the sample CSVs in
  `data-pipeline/sample_data/` exist for exactly this: iterate on
  interactions without waiting on real data exports.
