# Phase 4 · The World — Import terrain & geographic data

## Two approaches

### Option A — Cesium for Unity
Stream real-world terrain, imagery, and elevation directly from Cesium ion.
Fastest way to see the real basin in 3D; needs an internet connection at
runtime.

### Option B — DEM → Unity Terrain
Convert a USGS elevation raster (GeoTIFF) to a heightmap in QGIS/GDAL, then
import into Unity's built-in Terrain tools. Works fully offline — better for
a bounded watershed demo.

## Add the river network

Draw upstream/downstream reaches with line renderers, and place markers at
each gauge station using your geographic coordinates. See
`unity-project/Assets/Scripts/Terrain/RiverNetworkRenderer.cs` for a starting
point, and `unity-project/Assets/Scripts/Interaction/StationMarker.cs` for
the gauge-station marker script.

## Resources

- Cesium for Unity — Quickstart — cesium.com/learn/unity/unity-quickstart
- Cesium for Unity — Adding Datasets — cesium.com/learn/unity/unity-datasets
- Unity Terrain tools manual — docs.unity3d.com (Terrain system)

## Recommendation

For a lab demo of one bounded watershed, Option B (offline DEM → Terrain) is
usually the safer choice — no runtime network dependency during a
conference/stakeholder demo.
