# Before You Start — Tips for Success & Common Pitfalls

1. **Start simple** — get a single cube rendering and stable in the headset
   before importing any real terrain or data.
2. **Use version control** — Git plus Git LFS for large terrain and asset
   files; set this up before the project grows. (This repo is the starting
   point — add Git LFS tracking for `.fbx`, `.png`, `.psd`, terrain data,
   etc. once real assets land.)
3. **Decouple data from rendering** — a clean ScriptableObject data layer
   means new datasets or a new model version won't break the scene. This is
   why `StationDatabase.cs` is the single source of truth in this scaffold.
4. **Watch performance from day one** — profile after every major addition;
   catching a frame-rate regression early is far easier than fixing it at
   the end.
5. **Check in weekly** — short, regular check-ins with your advisor catch
   wrong turns before a week of work is wasted.
6. **Time-box the unknowns** — if a tutorial or tool isn't working after a
   couple of focused hours, ask for help rather than debugging alone all
   day.
