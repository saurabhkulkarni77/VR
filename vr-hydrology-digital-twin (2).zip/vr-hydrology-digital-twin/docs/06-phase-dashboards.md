# Phase 6 · Interaction — Dashboards & charts in VR

## What to build

- **World-space UI panels** — anchored in 3D so the player walks up and reads
  them, built with XR Interaction Toolkit UI or Unity 6.2's World-Space UI
  Toolkit. Starting point: `unity-project/Assets/Scripts/UI/StationPanelController.cs`.
- **Station detail panel** — shows current reading, a historical hydrograph,
  and the forecast line with its uncertainty band.
- **Layer toggles** — simple buttons to switch soil, climate, or
  river-network overlays on and off. Starting point:
  `unity-project/Assets/Scripts/UI/LayerToggleController.cs`.
- **Chart options** — custom `LineRenderer`/mesh charts, an asset-store chart
  package, or the Immersive Analytics Toolkit (IATK), built specifically for
  VR data viz.

## How the pieces connect

`StationMarker.cs` (Phase 4/8) fires a UnityEvent with the tapped station's
ID → `StationPanelController.cs` looks that station up in the shared
`StationDatabase` ScriptableObject → populates the panel's text/chart from the
`readings` and `forecast` arrays already loaded by Phase 5's data layer.

## Resources

- Immersive Analytics Toolkit (IATK) — GitHub, VR-native data visualization
- Unity Learn: UI best practices for VR — learn.unity.com
