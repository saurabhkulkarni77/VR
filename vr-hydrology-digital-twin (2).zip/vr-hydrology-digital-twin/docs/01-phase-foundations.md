# Phase 1 · Foundations — VR & Meta Quest 3S fundamentals

## Concepts to learn first

- **VR vs. AR vs. mixed reality** — the Quest 3S supports both full VR and
  passthrough mixed reality; know which mode your scene needs.
- **6-DOF tracking & room-scale** — how the headset tracks head and controller
  position/rotation in real space.
- **Controllers & hand tracking** — Touch Plus controllers, plus optional
  hands-only interaction.
- **Comfort & frame rate** — 90–120 Hz target; low frame rate causes motion
  sickness. Keep this in mind from day one.
- **Quest 3S hardware** — Snapdragon XR2 Gen 2, 8 GB RAM, 128/256 GB storage,
  dual LCD panels at 1832×1920 per eye.

## Resources

- Meta Quest 3S overview — developers.meta.com/horizon (device & spec docs)
- Unity: VR and MR development — docs.unity3d.com/Manual/VROverview.html
- Unity VR Tutorial for Beginners — xrbootcamp.com (step-by-step intro)

## Done when

You can explain, in your own words, the difference between VR/AR/MR, why
frame rate matters for comfort, and what hardware the Quest 3S is running.
