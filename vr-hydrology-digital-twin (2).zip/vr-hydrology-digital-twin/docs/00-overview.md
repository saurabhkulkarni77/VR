# Project Overview

**From Streamflow Model to VR Digital Twin** — a step-by-step build path for
deploying a hydrology forecasting model and its dataset onto a Meta Quest 3S
headset as an interactive VR digital twin.

- **Target device:** Meta Quest 3S
- **Engine:** Unity (URP)

## What we're building

- **An immersive digital twin** — walk through the actual watershed in 3D
  (terrain, river network, gauge stations) instead of viewing flat charts.
- **Live access to the ML forecasts** — reach into the scene and pull up
  streamflow forecasts with uncertainty bounds at any station.
- **A stronger demo for stakeholders** — sponsors, agencies, and collaborators
  can put on the headset and directly experience the model's output.

## Why VR specifically

- Spatial context — elevation, upstream/downstream relationships, and soil
  zones are naturally 3D.
- Interaction beats static reports — tap a station, see its forecast
  instantly.
- The Quest 3S is standalone — no PC or cables needed for demos in the field
  or at conferences.

## Starting point — what you already have

1. **Streamflow / discharge records** — historical water discharge time
   series from USGS gauge stations.
2. **Climate data** — geographic temperature and climate variables across the
   watershed.
3. **Watershed geography** — upstream/downstream river network and basin maps.
4. **Soil data** — soil characteristics used as model inputs.
5. **Forecasting model** — the ML model producing streamflow forecasts.
6. **Uncertainty bounds** — confidence intervals attached to every forecast.

## The target pipeline

```
Data Sources            Preprocessing         ML Forecast Model        Export Layer            Unity Application         Meta Quest 3S
USGS discharge      ->  Cleaning,         ->  Streamflow forecast  ->  JSON / ONNX / API   ->  Terrain, data, UI,   ->  Deployed VR
Climate/Soil/GIS        formatting (Python)   + uncertainty bounds                             model logic              digital twin
```

The first two stages (data sources, preprocessing) already exist in the lab's
research workflow — this project does not rebuild them. This repo focuses on
the last four stages: packaging model output (`data-pipeline/`) and the Unity
application that runs on the Quest 3S (`unity-project/`).

## Ten-phase roadmap

1. VR & Quest 3S fundamentals
2. Development environment setup
3. First VR scene ("Hello World")
4. Terrain & GIS import
5. Data pipeline integration
6. Interactive dashboards & charts
7. ML forecast model integration
8. Full digital twin scene assembly
9. Testing & performance optimization
10. Build & deploy to headset

See the numbered files in this folder for each phase's checklist and
resources, `roadmap-12-week-plan.md` for pacing, and `pitfalls-and-tips.md`
before you start.
