# VR Hydrology Digital Twin — Starter Project

A starter scaffold for turning a streamflow forecasting model into an interactive
VR digital twin on the **Meta Quest 3S**, built with **Unity**. This repository
implements the project laid out in the lab's *Student Onboarding Guide: From
Streamflow Model to VR Digital Twin* (September 2026).

> **Status:** starter scaffold, not a finished app. Unity itself has to run in
> the Unity Editor on a developer's machine — this repo gives you the pieces
> that don't need the editor (the data pipeline, a real live dataset, the
> project's folder layout, and the core C# scripts) so Phases 1–5 of the guide
> start from working code instead of a blank project. See `docs/` for how each
> phase maps to what's here.
>
> The dataset committed here is **real, live data** — discharge from USGS and
> temperature/precipitation from the National Weather Service for three
> Trinity River gauges near Dallas, TX, captured 2026-09-09 — not synthetic
> placeholders. See [`data-pipeline/README.md`](data-pipeline/README.md).

## What this project builds

An immersive digital twin of a watershed: walk the terrain in VR, tap a gauge
station, and see its live streamflow forecast with uncertainty bounds — all on
a standalone Meta Quest 3S headset, no PC required for the demo.

## Repository layout

```
.
├── docs/                    Phase-by-phase guide, 12-week plan, resources, pitfalls
├── data-pipeline/           Python: live/synthetic CSV -> per-station JSON (Phase 5)
│   ├── fetch_live_data.py   Real USGS discharge + Open-Meteo climate, per station
│   ├── generate_sample_data.py  Synthetic data generator (offline fallback)
│   ├── export_station_json.py
│   ├── sample_data/         Currently a real live snapshot (2026-09-09), not synthetic
│   └── output/              Generated JSON lands here (StreamingAssets-ready)
└── unity-project/           Unity project skeleton (Phases 3–8)
    ├── Assets/Scripts/Data/         Station data model + ScriptableObject database
    ├── Assets/Scripts/UI/           World-space station panel + layer toggles
    ├── Assets/Scripts/Interaction/  XR-interactable gauge station markers
    ├── Assets/Scripts/Terrain/      River network line-renderer stub
    ├── Assets/StreamingAssets/stations/  Copy of the pipeline's JSON output
    └── Packages/manifest.json       UPM packages this project needs
```

## Quick start

### 1. Get the dataset flowing

```bash
cd data-pipeline
pip install -r requirements.txt
python fetch_live_data.py       # real USGS + Open-Meteo data (needs normal internet access)
python export_station_json.py   # packages sample_data/ CSVs into StreamingAssets JSON
```

`sample_data/` already ships with a real live snapshot (USGS discharge + NWS
temperature/precipitation, captured 2026-09-09) — running `export_station_json.py`
alone regenerates the JSON from what's already there. Run `fetch_live_data.py`
first to refresh it with a fresh 30-day pull (see the network note in
`data-pipeline/README.md` — it needs a normal internet connection, not a
locked-down sandbox). Prefer offline iteration? `python generate_sample_data.py`
swaps in seeded synthetic data instead. Either way, the schema is documented
in [`docs/05-phase-data-pipeline.md`](docs/05-phase-data-pipeline.md).

### 2. Open the Unity project

1. Install **Unity 6000.0.66f2+** via Unity Hub, with Android Build Support.
2. Open `unity-project/` as an existing project in Unity Hub.
3. Follow [`docs/01-phase-foundations.md`](docs/01-phase-foundations.md)
   onward — Phase 2 walks through installing the Meta XR Core SDK and XR
   Interaction Toolkit that this project's scripts assume are present
   (listed in `Packages/manifest.json`).
4. The scripts in `Assets/Scripts/Data` load the JSON produced in step 1 from
   `StreamingAssets/stations/` into a single `StationDatabase` ScriptableObject
   — everything else in the scene (markers, panels, charts) reads from that
   one source, per the guide's Phase 8 recommendation.

### 3. Follow the phase docs

Each phase of the original guide has a matching file in `docs/`, with the
checklists and resource links carried over so you don't need to reopen the
slide deck while you work:

| Phase | Doc |
|---|---|
| 1. VR & Quest 3S fundamentals | [docs/01-phase-foundations.md](docs/01-phase-foundations.md) |
| 2. Development environment setup | [docs/02-phase-setup.md](docs/02-phase-setup.md) |
| 3. First VR scene ("Hello World") | [docs/03-phase-first-scene.md](docs/03-phase-first-scene.md) |
| 4. Terrain & GIS import | [docs/04-phase-terrain-gis.md](docs/04-phase-terrain-gis.md) |
| 5. Data pipeline integration | [docs/05-phase-data-pipeline.md](docs/05-phase-data-pipeline.md) |
| 6. Interactive dashboards & charts | [docs/06-phase-dashboards.md](docs/06-phase-dashboards.md) |
| 7. ML forecast model integration | [docs/07-phase-ml-model.md](docs/07-phase-ml-model.md) |
| 8. Full digital twin scene assembly | [docs/08-phase-assembly.md](docs/08-phase-assembly.md) |
| 9. Testing & performance optimization | [docs/09-phase-testing-performance.md](docs/09-phase-testing-performance.md) |
| 10. Build & deploy to headset | [docs/10-phase-build-deploy.md](docs/10-phase-build-deploy.md) |

Also see [docs/roadmap-12-week-plan.md](docs/roadmap-12-week-plan.md),
[docs/pitfalls-and-tips.md](docs/pitfalls-and-tips.md), and
[docs/resources.md](docs/resources.md).

## Target hardware

Meta Quest 3S — Snapdragon XR2 Gen 2, 8 GB RAM, dual LCD panels at 1832×1920
per eye. Target 90 fps in-headset (see `docs/09-phase-testing-performance.md`).

## License

MIT — see [LICENSE](LICENSE).
