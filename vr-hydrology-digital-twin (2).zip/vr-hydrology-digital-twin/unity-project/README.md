# Unity Project — VR Hydrology Digital Twin

This folder is a Unity project skeleton, not a full Unity project export —
Unity generates its `Library/`, `Temp/`, `obj/`, and `.meta` files the first
time it opens a project, and those are intentionally excluded by `.gitignore`
(they're large, machine-specific, and regenerate automatically).

## Opening it

1. Install **Unity 6000.0.66f2 or later** via Unity Hub, with Android Build
   Support, OpenJDK, and Android SDK & NDK modules (`docs/02-phase-setup.md`
   in the repo root).
2. In Unity Hub, **Add** this `unity-project/` folder as an existing project
   and open it. Unity will import the packages listed in
   `Packages/manifest.json` and generate its own metadata on first open.
3. Install the **Meta XR Core SDK** from the Unity Asset Store (it isn't
   distributed via the UPM registry, so it isn't in `manifest.json`) and run
   `Meta XR Tools → Project Setup Tool → Fix All`.
4. Create an empty scene, add an `XR Origin (VR)`, and start from
   `docs/03-phase-first-scene.md`.

## What's here

```
Assets/
├── Scripts/
│   ├── Data/
│   │   ├── StationData.cs        Typed models matching the pipeline's JSON schema
│   │   ├── StationDatabase.cs    ScriptableObject — single source of truth for station data
│   │   └── StationDataLoader.cs  Loads StreamingAssets/stations/*.json at runtime
│   ├── UI/
│   │   ├── StationPanelController.cs  World-space station detail panel
│   │   └── LayerToggleController.cs   Soil / climate / river overlay toggles
│   ├── Interaction/
│   │   └── StationMarker.cs      Attach to a gauge-station prefab; opens its panel on select
│   └── Terrain/
│       └── RiverNetworkRenderer.cs  LineRenderer-based river reach starting point
└── StreamingAssets/
    └── stations/                 Generated station JSON (from data-pipeline/), ships with the app
```

None of these scripts build a scene by themselves — they're the data and
interaction layer the guide's Phases 3–8 assemble into one. Terrain, prefabs,
materials, and the actual scene file are the parts you'll build by hand in
the Editor following `docs/03-phase-first-scene.md` onward, wiring these
scripts onto the GameObjects you create.

## Regenerating the station data

From the repo root:

```bash
cd data-pipeline
python fetch_live_data.py       # optional: refresh sample_data/ with real USGS + Open-Meteo data
python export_station_json.py
```

This overwrites `Assets/StreamingAssets/stations/*.json` with fresh output
from `data-pipeline/sample_data/` (or your real CSVs, once wired up).
