using System.Collections.Generic;
using UnityEngine;

namespace HydrologyTwin.Terrain
{
    /// <summary>
    /// Phase 4 starting point: draws upstream/downstream river reaches with a
    /// LineRenderer from a list of world-space points. Populate `reaches`
    /// with points converted from your basin's geographic coordinates (e.g.
    /// via the same lat/lon -> Unity-space conversion you use to place
    /// StationMarker prefabs), or replace this with Cesium's own line
    /// rendering if you choose Option A (Cesium for Unity) instead of Option
    /// B (DEM -> Unity Terrain) -- see docs/04-phase-terrain-gis.md.
    /// </summary>
    [RequireComponent(typeof(LineRenderer))]
    public class RiverNetworkRenderer : MonoBehaviour
    {
        [System.Serializable]
        public class Reach
        {
            public string reachName;
            public List<Vector3> points = new List<Vector3>();
        }

        [SerializeField] private List<Reach> reaches = new List<Reach>();
        [SerializeField] private float lineWidth = 0.5f;
        [SerializeField] private Color riverColor = new Color(0.2f, 0.5f, 0.9f);

        private void Start()
        {
            Render();
        }

        public void Render()
        {
            // This starter component renders only the first reach via the
            // required LineRenderer; for multiple reaches, instantiate one
            // LineRenderer child per Reach instead.
            if (reaches.Count == 0) return;

            var lr = GetComponent<LineRenderer>();
            var points = reaches[0].points;

            lr.positionCount = points.Count;
            lr.SetPositions(points.ToArray());
            lr.startWidth = lineWidth;
            lr.endWidth = lineWidth;
            lr.startColor = riverColor;
            lr.endColor = riverColor;
        }
    }
}
