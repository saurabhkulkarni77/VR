using System;
using System.Collections.Generic;
using UnityEngine;

namespace HydrologyTwin.UI
{
    /// <summary>
    /// Phase 6/8: simple buttons to switch soil, climate, or river-network
    /// overlays on and off without leaving VR. Wire each named layer's root
    /// GameObject in the Inspector, then hook a world-space UI button's
    /// OnClick to ToggleLayer("soil") etc.
    /// </summary>
    public class LayerToggleController : MonoBehaviour
    {
        [Serializable]
        public class Layer
        {
            public string layerName;
            public GameObject root;
            public bool startVisible = true;
        }

        [SerializeField] private List<Layer> layers = new List<Layer>();

        private readonly Dictionary<string, Layer> _byName = new Dictionary<string, Layer>();

        private void Awake()
        {
            foreach (var layer in layers)
            {
                if (layer.root == null || string.IsNullOrEmpty(layer.layerName)) continue;
                _byName[layer.layerName] = layer;
                layer.root.SetActive(layer.startVisible);
            }
        }

        public void ToggleLayer(string layerName)
        {
            if (!_byName.TryGetValue(layerName, out var layer))
            {
                Debug.LogWarning($"LayerToggleController: unknown layer '{layerName}'.");
                return;
            }

            layer.root.SetActive(!layer.root.activeSelf);
        }

        public void SetLayerVisible(string layerName, bool visible)
        {
            if (!_byName.TryGetValue(layerName, out var layer))
            {
                Debug.LogWarning($"LayerToggleController: unknown layer '{layerName}'.");
                return;
            }

            layer.root.SetActive(visible);
        }
    }
}
