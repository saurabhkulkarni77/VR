using System.Text;
using HydrologyTwin.Data;
using UnityEngine;

namespace HydrologyTwin.UI
{
    /// <summary>
    /// World-space station detail panel (Phase 6): current reading, a
    /// historical hydrograph, and the forecast line with its uncertainty
    /// band. This starter version renders the numbers as text; swap
    /// summaryText for a LineRenderer/mesh chart, an asset-store chart
    /// package, or IATK once you get to the charting step -- the data-access
    /// pattern (look the station up in StationDatabase, read .readings and
    /// .forecast) stays the same.
    /// </summary>
    public class StationPanelController : MonoBehaviour
    {
        [SerializeField] private StationDatabase database;
        [SerializeField] private TMPro.TMP_Text titleText;
        [SerializeField] private TMPro.TMP_Text summaryText;
        [SerializeField] private GameObject panelRoot;

        public string CurrentStationId { get; private set; }

        public void ShowStation(string stationId)
        {
            if (database == null)
            {
                Debug.LogError("StationPanelController: no StationDatabase assigned.");
                return;
            }

            if (!database.TryGetStation(stationId, out var record))
            {
                Debug.LogWarning($"StationPanelController: unknown station '{stationId}'.");
                return;
            }

            CurrentStationId = stationId;

            if (panelRoot != null) panelRoot.SetActive(true);
            if (titleText != null) titleText.text = record.name;
            if (summaryText != null) summaryText.text = BuildSummary(record);
        }

        public void Hide()
        {
            if (panelRoot != null) panelRoot.SetActive(false);
            CurrentStationId = null;
        }

        private static string BuildSummary(StationRecord record)
        {
            var sb = new StringBuilder();

            var latest = record.LatestReading;
            if (latest != null)
            {
                sb.AppendLine($"Current discharge ({latest.date}): {latest.dischargeCfs:0.0} cfs");
            }

            var next = record.NextForecast;
            if (next != null)
            {
                sb.AppendLine(
                    $"Forecast ({next.date}): {next.dischargeCfs:0.0} cfs " +
                    $"[{next.lowerBound:0.0} - {next.upperBound:0.0}]");
            }

            if (record.climate != null)
            {
                sb.AppendLine($"Avg temp: {record.climate.avgTempC:0.0} C, " +
                               $"avg precip: {record.climate.avgPrecipMm:0.0} mm");
            }

            if (record.soil != null)
            {
                sb.AppendLine($"Soil: {record.soil.type} " +
                               $"({record.soil.infiltrationRateMmHr:0.0} mm/hr infiltration)");
            }

            return sb.ToString();
        }
    }
}
