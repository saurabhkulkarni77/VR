using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;

namespace HydrologyTwin.Data
{
    /// <summary>
    /// Loads every *.json file from Assets/StreamingAssets/stations/ (produced by
    /// data-pipeline/export_station_json.py) and populates a StationDatabase.
    /// Uses UnityWebRequest rather than System.IO.File because StreamingAssets is
    /// not a plain filesystem path on Android/Quest -- see docs/05-phase-data-pipeline.md.
    /// </summary>
    public class StationDataLoader : MonoBehaviour
    {
        [SerializeField] private StationDatabase database;
        [SerializeField] private string streamingAssetsSubfolder = "stations";

        /// <summary>List of station JSON filenames to load. If empty, StationManifest.json
        /// (also written by the export pipeline) is used to discover them at runtime.</summary>
        [SerializeField] private List<string> knownStationFiles = new List<string>();

        private IEnumerator Start()
        {
            if (database == null)
            {
                Debug.LogError("StationDataLoader: no StationDatabase assigned.");
                yield break;
            }

            var files = knownStationFiles.Count > 0
                ? knownStationFiles
                : Directory.Exists(BuildStreamingAssetsPath())
                    ? new List<string>(Directory.GetFiles(BuildStreamingAssetsPath(), "*.json"))
                    : new List<string>();

            var loaded = new List<StationRecord>();

            foreach (var file in files)
            {
                var fileName = Path.GetFileName(file);
                var url = BuildUrl(fileName);

                using var request = UnityWebRequest.Get(url);
                yield return request.SendWebRequest();

                if (request.result != UnityWebRequest.Result.Success)
                {
                    Debug.LogWarning($"StationDataLoader: failed to load {url}: {request.error}");
                    continue;
                }

                var record = JsonUtility.FromJson<StationRecord>(request.downloadHandler.text);
                if (record != null)
                {
                    loaded.Add(record);
                }
            }

            database.SetStations(loaded);
            Debug.Log($"StationDataLoader: loaded {loaded.Count} station(s) into {database.name}.");

            // TODO (Phase 5, "live API refresh"): on a timer, hit the USGS
            // Water Services API (waterservices.usgs.gov/nwis/iv) with a
            // UnityWebRequest coroutine and call database.SetStations() again
            // with the refreshed readings when the headset is on WiFi.
        }

        private string BuildStreamingAssetsPath()
        {
            return Path.Combine(Application.streamingAssetsPath, streamingAssetsSubfolder);
        }

        private string BuildUrl(string fileName)
        {
            var path = Path.Combine(BuildStreamingAssetsPath(), fileName);
            // On Android, streamingAssetsPath is a jar:// URL that UnityWebRequest
            // can read directly; on desktop/editor it's a plain file path.
            return path.Contains("://") ? path : "file://" + path;
        }
    }
}
