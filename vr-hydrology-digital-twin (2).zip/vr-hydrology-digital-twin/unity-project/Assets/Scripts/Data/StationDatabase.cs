using System.Collections.Generic;
using UnityEngine;

namespace HydrologyTwin.Data
{
    /// <summary>
    /// Single source of truth for all station data in the scene (Phase 8's
    /// "one central ScriptableObject" recommendation). Terrain, UI, and
    /// interaction scripts all read from this asset instead of loading or
    /// duplicating data themselves -- see docs/08-phase-assembly.md.
    ///
    /// Create an instance via Assets > Create > Hydrology Twin > Station Database,
    /// drop it in the scene's bootstrap object, and assign it to
    /// StationDataLoader and every script that needs station lookups.
    /// </summary>
    [CreateAssetMenu(fileName = "StationDatabase", menuName = "Hydrology Twin/Station Database")]
    public class StationDatabase : ScriptableObject
    {
        [SerializeField]
        private List<StationRecord> stations = new List<StationRecord>();

        private Dictionary<string, StationRecord> _byId;

        public IReadOnlyList<StationRecord> Stations => stations;

        /// <summary>Replaces all station data. Called by StationDataLoader after parsing JSON.</summary>
        public void SetStations(List<StationRecord> newStations)
        {
            stations = newStations ?? new List<StationRecord>();
            RebuildIndex();
        }

        public bool TryGetStation(string stationId, out StationRecord record)
        {
            if (_byId == null) RebuildIndex();
            return _byId.TryGetValue(stationId, out record);
        }

        private void RebuildIndex()
        {
            _byId = new Dictionary<string, StationRecord>();
            foreach (var s in stations)
            {
                if (s != null && !string.IsNullOrEmpty(s.stationId))
                    _byId[s.stationId] = s;
            }
        }

        private void OnEnable()
        {
            RebuildIndex();
        }
    }
}
