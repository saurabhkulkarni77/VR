using System;
using System.Collections.Generic;

namespace HydrologyTwin.Data
{
    /// <summary>
    /// Typed data model matching the JSON schema produced by
    /// data-pipeline/export_station_json.py (see docs/05-phase-data-pipeline.md).
    /// All classes are [Serializable] so they work with Unity's JsonUtility.
    /// JsonUtility can't deserialize a top-level array, so each station is
    /// loaded as a single JSON object -- see StationDataLoader.
    /// </summary>
    [Serializable]
    public class StationReading
    {
        public string date;
        public float dischargeCfs;
    }

    /// <summary>Inclusive [start, end] date interval, used for both the
    /// discharge "period" and the "forecastPeriod".</summary>
    [Serializable]
    public class DateRange
    {
        public string start;
        public string end;
    }

    [Serializable]
    public class ClimateInfo
    {
        public float avgTempC;
        public float avgPrecipMm;

        /// <summary>Date this climate reading was captured as-of. Present for a
        /// live single-point pull; may be empty/null for older or synthetic data.</summary>
        public string asOfDate;
    }

    [Serializable]
    public class SoilInfo
    {
        public string type;
        public float infiltrationRateMmHr;
    }

    [Serializable]
    public class ForecastPoint
    {
        public string date;
        public float dischargeCfs;
        public float lowerBound;
        public float upperBound;
    }

    [Serializable]
    public class StationRecord
    {
        public string stationId;
        public string name;
        public float latitude;
        public float longitude;

        /// <summary>Start/end date of the readings array below -- read this
        /// instead of scanning readings[0] / readings[^1] for the interval.</summary>
        public DateRange period;
        public List<StationReading> readings = new List<StationReading>();
        public ClimateInfo climate;
        public SoilInfo soil;

        /// <summary>Start/end date of the forecast array below.</summary>
        public DateRange forecastPeriod;
        public List<ForecastPoint> forecast = new List<ForecastPoint>();

        /// <summary>Most recent historical discharge reading, or null if none loaded.</summary>
        public StationReading LatestReading =>
            readings != null && readings.Count > 0 ? readings[readings.Count - 1] : null;

        /// <summary>Next forecast point (soonest date), or null if none loaded.</summary>
        public ForecastPoint NextForecast =>
            forecast != null && forecast.Count > 0 ? forecast[0] : null;
    }
}
