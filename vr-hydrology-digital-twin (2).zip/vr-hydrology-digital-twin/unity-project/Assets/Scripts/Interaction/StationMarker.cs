using HydrologyTwin.Data;
using HydrologyTwin.UI;
using UnityEngine;
using UnityEngine.Events;

namespace HydrologyTwin.Interaction
{
    /// <summary>
    /// Attach to a gauge-station marker prefab placed in the scene at the
    /// station's geographic position (see docs/04-phase-terrain-gis.md). Wire
    /// this object's XR Simple Interactable "Select Entered" event to
    /// OnStationSelected (Phase 6/8 interaction loop).
    ///
    /// Kept decoupled from the interaction toolkit's concrete types so this
    /// script compiles even before XR Interaction Toolkit is installed --
    /// wire the UnityEvent from the Inspector once it is.
    /// </summary>
    public class StationMarker : MonoBehaviour
    {
        [SerializeField] private string stationId;
        [SerializeField] private StationPanelController panel;

        public UnityEvent<string> OnStationSelected;

        public string StationId => stationId;

        /// <summary>Call this from an XR Interactable's "Select Entered" UnityEvent,
        /// or directly from any input system, to open this station's panel.</summary>
        public void Select()
        {
            if (string.IsNullOrEmpty(stationId))
            {
                Debug.LogWarning($"StationMarker on {name} has no stationId set.");
                return;
            }

            OnStationSelected?.Invoke(stationId);

            if (panel != null)
            {
                panel.ShowStation(stationId);
            }
        }
    }
}
